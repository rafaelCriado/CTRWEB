<HTML><HEAD>
<meta http-equiv="Content-Language" content="pt-br">
<TITLE>...&#58;&#58;&#58;&nbsp;FORMUL&Aacute;RIO&nbsp;DE&nbsp;CADASTRO&nbsp;PESSOA&nbsp;J&Uacute;RIDICA&nbsp;&#58;&#58;&#58;...</TITLE>
<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
<META content="Microsoft FrontPage 4.0" name=GENERATOR>
<!----Pedimos a colabora��o aos usu�rios deste formul�rio, que n�o retirem os dados dos direitos autorais------>
<!----Formul�rio desenvolvido por Nascimento Grupo NASCTEM - e-mail: admin@nasctem.com nasctem@yahoo.com.br------>
<!----Formul�rio desenvolvido em 20/08/2004 a primeira vers�o, somente agora estamos disponibilizando 
a vers�o atualizada do mesmo v2.8.0 em 03/04/2007------->
<!----D�vidas utilize o nosso e-mail: suporte@nasctem.com------>
<STYLE>.cellbox {
	BORDER-RIGHT: #888888 1px solid; PADDING-RIGHT: 5px; BORDER-TOP: #888888 1px solid; PADDING-LEFT: 5px; PADDING-BOTTOM: 5px; BORDER-LEFT: #888888 1px solid; PADDING-TOP: 5px; BORDER-BOTTOM: #888888 1px solid
}
.box-header {
	PADDING-RIGHT: 5px; PADDING-LEFT: 5px; PADDING-BOTTOM: 5px; PADDING-TOP: 5px
}
.frm {
	BORDER-RIGHT: #888888 1px solid; BORDER-TOP: #888888 1px solid; FONT-WEIGHT: bold; FONT-SIZE: 8pt; BORDER-LEFT: #888888 1px solid; BORDER-BOTTOM: #888888 1px solid; FONT-FAMILY: Verdana; BACKGROUND-COLOR: #f0f0f0
}
.frm-on {
	BORDER-RIGHT: rgb(70,90,128) 1px solid; BORDER-TOP: rgb(70,90,128) 1px solid; FONT-WEIGHT: bold; FONT-SIZE: 8pt; BORDER-LEFT: rgb(70,90,128) 1px solid; COLOR: rgb(70,90,128); BORDER-BOTTOM: rgb(70,90,128) 1px solid; FONT-FAMILY: Verdana; BACKGROUND-COLOR: rgb(177,203,255)
}
.text-header {
	FONT-WEIGHT: bold; FONT-SIZE: 8pt; FONT-FAMILY: Verdana
}
.header {
	FONT-WEIGHT: bold; FONT-SIZE: 16pt; COLOR: rgb(0,128,255); FONT-FAMILY: Verdana
}
</STYLE>

<SCRIPT language=JavaScript>
<!--
function SymError()
{
  return true;
}
window.onerror = SymError;
//-->

    </SCRIPT>

<SCRIPT>
      function displayText( sText ) {
        document.getElementById("displayArea").innerHTML = sText;
      }
    </SCRIPT>

</HEAD>
<BODY bgcolor="#1FC8EB">
<DIV align=center>
<CENTER>

<table border="2" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#1FC8EB" width="507" id="AutoNumber2" height="85" bgcolor="#1FC8EB">
  <tr>
    <td width="563" height="85" valign="middle">
    <p align="center">
    <img border="0" src="images/seu_logo_aqui_01.gif" width="327" height="70"></td>
  </tr>
</table>

<TABLE id=AutoNumber1 style="BORDER-COLLAPSE: collapse" borderColor=#1FC8EB 
height=424 cellSpacing=0 cellPadding=0 width=507 border=1>
  <TBODY>
  <TR>
    <TD width=507 bgColor=#000000 height=18>
      <P style="MARGIN-TOP: 0px; MARGIN-BOTTOM: 0px" align=center><b><font face="Verdana" color="#ffffff" size="2">Formul&aacute;rio
     &nbsp;de&nbsp;Cadastro&nbsp;Pessoa&nbsp;J&uacute;ridica</font></b></P></TD></TR>
  <TR>
    <TD align=justify width=507 height=402>
      <DIV align=center>
      <CENTER>
                <TABLE id=AutoNumber1 style="BORDER-COLLAPSE: collapse" 
      borderColor=#111111 height=200 cellSpacing=0 cellPadding=0 width=328 
      border=0>                  
             <!--DWLayoutTable-->
                  <TBODY>
                    <TR> 
                      <TD width=67 height=44> </TD>
                      <TD width=251 height="44"></TD>
                      <TD width=66 height="44"></TD>
                    </TR>
					<?php
if (!$razaosocial || !$nomefantasia || !$cnpj || !$ie || !$im || !$ddd || !$telefone || !$fax || !$endereco || !$numero || !$complemento || !$bairro || !$cidade || !$cep || !$uf || !$email || !$responsavel || !$telresp || !$empresaref || !$telefoneref || !$contatoref || !$empresaref1 || !$telefoneref1 || !$contatoref1 || !$mensagem) {
 echo "<DIV align=center><p align=center><font face=Verdana, Arial size=2 color=#000066>Favor preencher os dados corretamente!<br>";
  echo "<a href=\"javascript:history.back(1)\">Voltar</a>";
 }else{
 echo "
                    <tr> 
                      <TD height=22 colspan=3> <p align=center><font face=Verdana size=2>Ol� 
                          <font color=#FF0000><b>$responsavel</b></font>,</font> 
                      </TD>
                    </tr>
                    <TR> 
                      <TD height=22 colspan=3> <p align=center><font face=Verdana size=2>Seu&nbsp;
                           Cadastro&nbsp;foi&nbsp;enviado&nbsp;com&nbsp;sucesso!</font> </TD>
                    </TR>
                    <tr> 
                      <TD height=22> </TD>
                      <TD></TD>
                      <TD></TD>
                    </tr>
                    <TR> 
                      <TD height=23 colspan=3> <p align=center><font face=Verdana size=2>No&nbsp;
                          m�ximo&nbsp;em&nbsp;72&nbsp;horas&nbsp;entraremos&nbsp;em&nbsp;contato.</font> </TD>
                    </TR>
                    <tr> 
                      <TD height=23 colspan=3> <p align=center><font face=Verdana size=2>Atenciosamente!<br><br><!--ALTERE AQUI PARA OS SEU DADOS--->AQUI SEUS DAODS</font> 
                      </TD>
                    </tr>";
 $mens = "<font size=2 face=Verdana><p align=center>&#58;&#58;&nbsp;Formul&aacute;rio&nbsp;de&nbsp;Cadastro&nbsp;Pessoa&nbsp;J&uacute;ridica&nbsp;&#58;&#58;<br><br></p></font>";
 $mens .= "<font size=2 face=Verdana><b>Raz�o Social:</b> $razaosocial</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>Nome Fantasia:</b> $nomefantasia</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>CNPJ:</b> $cnpj</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>IE:</b> $ie</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>IM:</b> $im</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>DDD:</b> $ddd</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>Telefone:</b> $telefone</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>Fax:</b> $fax</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>Endere�o:</b> $endereco</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>N�mero:</b> $numero</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>Complemento:</b> $complemento</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>Bairro:</b> $bairro</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>Cidade:</b> $cidade</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>CEP:</b> $cep</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>Estado:</b> $uf</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>Respons�vel:</b> $responsavel</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>Telefone:</b> $telresp</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>Empresa:</b> $empresaref</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>Telefone:</b> $telefoneref</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>Contato:</b> $contatoref</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>Empresa:</b> $empresaref1</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>Telefone:</b> $telefoneref1</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>Contato:</b> $contatoref1</font><br><br>";
 $mens .= "<font size=2 face=Verdana><b>Mensagem:</b> $mensagem</font><br><br>";

 $headers = "MIME-Version: 2.8.0\r\n";
 $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
 $headers .= "From: 'Formul�rio'\r\n";
 
   mail("seunome@seu_site.com.br","Formul�rio de Cadastro","$mens", $headers);
echo "                    <TR> 
                      <TD height=13> </TD>
                      <TD></TD>
                      <TD></TD>
                    </TR>
                    <TR>
                      <TD height=12></TD>
                      <TD valign=top><div align=center><font size=2 face=Verdana, Arial, Helvetica, sans-serif><a href=index.html>Voltar</a></font></div></TD>
                      <TD></TD>
                    </TR>";
					}
					?>
                    <TR>
                      <TD height=94></TD>
                      <TD>&nbsp;</TD>
                      <TD></TD>
                    </TR>
                    <tr> 
                      <TD height=12 colspan="3"> <p align="center"><font face="Verdana" size="1">...&#58;&#58;&#58;&nbsp;
                          Desenvolvido&nbsp;por&nbsp;<a href="mailto:comercial&#64;nasctem.com.br">Nascimento</a>&nbsp;&copy;&nbsp;Grupo NASCTEM&nbsp;&#58;&#58;&nbsp;Vers�o 2.8.0&nbsp;&#58;&#58;&#58;...</font></TD>
                    </tr>
                  </TBODY>
                </TABLE>
              </CENTER></DIV></FORM></TD></TR></TBODY></TABLE></CENTER></DIV></BODY></HTML>
